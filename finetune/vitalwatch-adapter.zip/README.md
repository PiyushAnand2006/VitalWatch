---
license: apache-2.0
base_model: Qwen/Qwen2.5-1.5B-Instruct
library_name: peft
tags: [vitalwatch, clinical-evidence, qlora, lora]
---

# VitalWatch Internal SLM (LoRA adapter)
Evidence compiler for the VitalWatch pipeline: converts retrieved medical report text into a
privacy-minimized evidence JSON package (schema v1.0). Decision-support only; not a
diagnostic device, not the temporal prediction model, not a privacy guarantee - all output must
pass the independent deterministic validator and privacy firewall before any external transmission.

Trained on ELMTEX (Zenodo 14793810, CC-BY-4.0) derived extraction examples plus clearly-labeled
synthetic edge cases. No real patient data (PHI) used.
